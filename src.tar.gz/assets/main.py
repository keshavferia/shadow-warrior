# -*- coding: utf-8 -*-

import asyncio
import os
import sys
import pygame
from player import Player

# SOUND FIX
pygame.mixer.pre_init(44100, -16, 2, 512)
pygame.mixer.pre_init(44100, -16, 2, 512)
pygame.init()

# ==========================================
# SCREEN
# ==========================================
WIDTH = 1280
HEIGHT = 720

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Shadow Warriors")

print("GAME START")

# ==========================================
# PATHS
# ==========================================
def resource_path(relative_path):
    base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, relative_path)

ASSET_FOLDER = resource_path("assets")
BACKGROUND_FOLDER = os.path.join(ASSET_FOLDER, "background")
CHARACTER_FOLDER = os.path.join(ASSET_FOLDER, "characters")
SOUND_FOLDER = os.path.join(ASSET_FOLDER, "sounds")

# ==========================================
# LOAD IMAGE
# ==========================================
def load_image(path, size=None):
    if not os.path.exists(path):
        print("IMAGE NOT FOUND:", path)
        surf = pygame.Surface((100, 100), pygame.SRCALPHA)
        surf.fill((255, 0, 255))
        return surf

    image = pygame.image.load(path).convert_alpha()

    if size:
        image = pygame.transform.scale(image, size)

    return image

# ==========================================
# LOAD SOUND
# ==========================================
def load_sound(filename):
    path = os.path.join(SOUND_FOLDER, filename)

    if not os.path.exists(path):
        print("SOUND NOT FOUND:", path)
        return None

    try:
        pygame.mixer.init()   
        return pygame.mixer.Sound(path)
    except Exception as e:
        print("SOUND ERROR:", path, e)
        return None

# ==========================================
# BACKGROUND
# ==========================================
background = load_image(
    os.path.join(BACKGROUND_FOLDER, "background.png"),
    (WIDTH, HEIGHT)
)

# ==========================================
# CHARACTERS
# ==========================================
creator1 = load_image(
    os.path.join(CHARACTER_FOLDER, "character1.png"),
    (300, 300)
)

creator2 = load_image(
    os.path.join(CHARACTER_FOLDER, "character2.png"),
    (300, 300)
)

character1_fighting = os.path.join(
    CHARACTER_FOLDER,
    "character1_fighting"
)

character2_fighting = os.path.join(
    CHARACTER_FOLDER,
    "character2_fighting"
)

# ==========================================
# SOUNDS
# ==========================================
game_start_sound = load_sound("game_start.ogg")
game_end_sound = load_sound("game_end.ogg")

tojo_punch_sound = load_sound("tojo_punch.ogg")
vidhi_punch_sound = load_sound("vidhi_punch.ogg")

tojo_special_sound = load_sound("tojo_special.ogg")
vidhi_special_sound = load_sound("vidhi_special.ogg")

# ==========================================
# PLAYERS
# ==========================================
tojo = Player(
    "Tojo",
    creator1,
    200,
    325,
    character1_fighting,
    tojo_punch_sound,
    tojo_special_sound
)

vidhi = Player(
    "Vidhi",
    creator2,
    800,
    340,
    character2_fighting,
    vidhi_punch_sound,
    vidhi_special_sound
)

# ==========================================
# FONTS
# ==========================================
title_font = pygame.font.SysFont("Arial", 60, bold=True)
font = pygame.font.SysFont("Arial", 40, bold=True)
small_font = pygame.font.SysFont("Arial", 24)
health_font = pygame.font.SysFont("Arial", 22, bold=True)

# ==========================================
# CLOCK
# ==========================================
clock = pygame.time.Clock()

# ==========================================
# STATES
# ==========================================
MENU = 0
PLAYING = 1
GAME_OVER = 2

game_state = MENU
winner = None
game_end_played = False

# ==========================================
# MAIN LOOP
# ==========================================
running = True

async def main():
    global running, game_state, winner, game_end_played

    while running:

        await asyncio.sleep(0)

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:

                if game_state == MENU:

                    if event.key == pygame.K_RETURN:

                        pygame.mixer.unpause()

                        game_state = PLAYING
                        winner = None
                        game_end_played = False

                        tojo.health = 100
                        vidhi.health = 100

                        tojo.is_dead = False
                        vidhi.is_dead = False

                        tojo.image = tojo.idle_image
                        vidhi.image = vidhi.idle_image

                        if game_start_sound:
                            game_start_sound.play()

                elif game_state == GAME_OVER:

                    if event.key == pygame.K_RETURN:
                        game_state = MENU
                        winner = None

                elif game_state == PLAYING:

                    if event.key == pygame.K_j:
                        tojo.attack(vidhi)

                    if event.key == pygame.K_l:
                        vidhi.attack(tojo)

                    if event.key == pygame.K_b:
                        tojo.block()

                    if event.key == pygame.K_p:
                        vidhi.block()

                    if event.key == pygame.K_k:
                        tojo.start_charge()

                    if event.key == pygame.K_o:
                        vidhi.start_charge()

            if event.type == pygame.KEYUP and game_state == PLAYING:

                if event.key == pygame.K_b:
                    tojo.stop_block()

                if event.key == pygame.K_p:
                    vidhi.stop_block()

                if event.key == pygame.K_k:
                    tojo.release_charge(vidhi)

                if event.key == pygame.K_o:
                    vidhi.release_charge(tojo)

        if game_state == PLAYING:

            keys = pygame.key.get_pressed()

            tojo.move(keys, pygame.K_a, pygame.K_d)
            vidhi.move(keys, pygame.K_LEFT, pygame.K_RIGHT)

            tojo.update()
            vidhi.update()

            if tojo.health <= 0:

                tojo.health = 0
                tojo.die()

                winner = "VIDHI"
                game_state = GAME_OVER

            elif vidhi.health <= 0:

                vidhi.health = 0
                vidhi.die()

                winner = "TOJO"
                game_state = GAME_OVER

            if game_state == GAME_OVER and not game_end_played:

                if game_end_sound:
                    game_end_sound.play()

                game_end_played = True

        screen.blit(background, (0, 0))

        if game_state == MENU:

            title = title_font.render(
                "SHADOW WARRIORS",
                True,
                (255, 255, 255)
            )

            screen.blit(
                title,
                (
                    WIDTH // 2 - title.get_width() // 2,
                    180
                )
            )

            start_text = font.render(
                "PRESS ENTER TO START",
                True,
                (255, 255, 0)
            )

            screen.blit(
                start_text,
                (
                    WIDTH // 2 - start_text.get_width() // 2,
                    350
                )
            )

        elif game_state == PLAYING:

            pygame.draw.rect(screen, (80, 0, 0), (40, 40, 300, 28))
            pygame.draw.rect(screen, (0, 220, 0), (40, 40, tojo.health * 3, 28))

            pygame.draw.rect(screen, (80, 0, 0), (940, 40, 300, 28))
            pygame.draw.rect(screen, (0, 220, 0), (940, 40, vidhi.health * 3, 28))

            screen.blit(
                health_font.render(f"{tojo.health}/100", True, (255, 255, 255)),
                (100, 75)
            )

            screen.blit(
                health_font.render(f"{vidhi.health}/100", True, (255, 255, 255)),
                (1000, 75)
            )

            screen.blit(font.render("TOJO", True, (255, 80, 80)), (50, 110))
            screen.blit(font.render("VIDHI", True, (80, 255, 80)), (1050, 110))

            title = font.render("SHADOW WARRIORS", True, (255, 255, 255))
            screen.blit(title, (420, 40))

            tojo.draw(screen)
            vidhi.draw(screen)

        pygame.display.flip()
        clock.tick(60)

    pygame.quit()

asyncio.run(main())