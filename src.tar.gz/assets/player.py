import os
import pygame


class Player:

    def __init__(
        self,
        name,
        image,
        x,
        y,
        folder,
        punch_sound=None,
        special_sound=None
    ):

        self.name = name
        self.folder = folder

        # -----------------------------
        # BASIC
        # -----------------------------

        self.idle_image = self.safe_scale(image, (300, 300))
        self.image = self.idle_image

        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

        self.speed = 7
        self.health = 100

        # -----------------------------
        # SOUNDS
        # -----------------------------

        self.punch_sound = punch_sound
        self.special_sound = special_sound

        # -----------------------------
        # BLOCK
        # -----------------------------

        self.block_image = self.load_image(
            "block.png",
            (300, 300)
        )

        if self.block_image is None:
            self.block_image = self.idle_image

        self.is_blocking = False

        # -----------------------------
        # PUNCH
        # -----------------------------

        self.punch_frames = self.load_frames(
            "punch",
            5,
            (300, 300)
        )

        # -----------------------------
        # RUNNING
        # -----------------------------

        self.running_frames = self.load_frames(
            "running",
            6,
            (300, 300)
        )

        # -----------------------------
        # SPECIAL
        # -----------------------------

        self.special_frames = self.load_frames(
            "special",
            4,
            (300, 300)
        )

        # -----------------------------
        # HIT
        # -----------------------------

        self.hit_frames = self.load_frames(
            "hit",
            3,
            (300, 300)
        )

        # -----------------------------
        # DEATH
        # -----------------------------

        self.death_image = self.load_image(
            "death.png",
            (300, 300)
        )

        if self.death_image is None:
            self.death_image = self.idle_image

        # -----------------------------
        # BLAST
        # -----------------------------

        self.blast_image = self.load_image(
            "blast.png",
            (180, 100)
        )

        self.blast_active = False
        self.blast_rect = pygame.Rect(0, 0, 180, 100)
        self.blast_speed = 12
        self.blast_direction = 1
        self.blast_enemy = None
        self.blast_damage_done = False

        # -----------------------------
        # ATTACK
        # -----------------------------

        self.is_attacking = False
        self.attack_frame = 0
        self.attack_timer = 0

        # -----------------------------
        # RUN
        # -----------------------------

        self.running_frame = 0
        self.running_timer = 0

        # -----------------------------
        # SPECIAL STATE
        # -----------------------------

        self.is_charging = False
        self.is_special = False
        self.special_frame = 0
        self.special_timer = 0

        # -----------------------------
        # HIT STATE
        # -----------------------------

        self.is_hit = False
        self.hit_frame = 0
        self.hit_timer = 0

        # -----------------------------
        # DEATH
        # -----------------------------

        self.is_dead = False

    # ==================================================
    # SAFE IMAGE SCALE
    # ==================================================

    def safe_scale(self, image, size):

        if image is None:
            return pygame.Surface(size, pygame.SRCALPHA)

        try:
            return pygame.transform.scale(image, size)
        except pygame.error:
            return pygame.Surface(size, pygame.SRCALPHA)

    # ==================================================
    # LOAD IMAGE
    # ==================================================

    def load_image(self, filename, size):

        path = os.path.join(self.folder, filename)

        if not os.path.isfile(path):
            return None

        try:
            image = pygame.image.load(path)

            if pygame.display.get_surface() is not None:
                image = image.convert_alpha()

            image = pygame.transform.scale(image, size)

            return image

        except (pygame.error, OSError):
            return None

    # ==================================================
    # LOAD ANIMATION FRAMES
    # ==================================================

    def load_frames(self, prefix, count, size):

        frames = []

        for number in range(1, count + 1):

            filename = f"{prefix}{number}.png"

            image = self.load_image(
                filename,
                size
            )

            if image is not None:
                frames.append(image)

        return frames

    # ==================================================
    # MOVE
    # ==================================================

    def move(self, keys, left, right):

        if self.is_dead:
            return

        if self.is_blocking:
            return

        if self.is_attacking:
            return

        if self.is_special:
            return

        if self.is_charging:
            return

        if self.is_hit:
            return

        moving = False

        if keys[left]:
            self.rect.x -= self.speed
            moving = True

        if keys[right]:
            self.rect.x += self.speed
            moving = True

        # Screen boundaries

        if self.rect.left < 0:
            self.rect.left = 0

        if self.rect.right > 1280:
            self.rect.right = 1280

        # Running animation

        if moving and self.running_frames:

            self.running_timer += 1

            if self.running_timer >= 5:

                self.running_timer = 0

                self.image = self.running_frames[
                    self.running_frame
                ]

                self.running_frame += 1

                if self.running_frame >= len(
                    self.running_frames
                ):
                    self.running_frame = 0

        else:

            self.running_frame = 0
            self.running_timer = 0

            if not self.is_attacking:
                self.image = self.idle_image

    # ==================================================
    # BLOCK
    # ==================================================

    def block(self):

        if self.is_dead:
            return

        if self.is_attacking:
            return

        if self.is_special:
            return

        if self.is_hit:
            return

        self.is_blocking = True
        self.image = self.block_image

    # ==================================================
    # STOP BLOCK
    # ==================================================

    def stop_block(self):

        self.is_blocking = False

        if self.is_dead:
            return

        if not self.is_attacking:
            self.image = self.idle_image

    # ==================================================
    # NORMAL ATTACK
    # ==================================================

    def attack(self, enemy):

        if self.is_dead:
            return

        if self.is_attacking:
            return

        if self.is_blocking:
            return

        if self.is_special:
            return

        if self.is_charging:
            return

        if self.is_hit:
            return

        self.is_attacking = True
        self.attack_frame = 0
        self.attack_timer = 0

        if self.punch_sound is not None:

            try:
                self.punch_sound.play()
            except pygame.error:
                pass

        # Damage only when close

        if self.rect.colliderect(enemy.rect):

            enemy.take_damage(5)

    # ==================================================
    # START SPECIAL CHARGE
    # ==================================================

    def start_charge(self):

        if self.is_dead:
            return

        if self.is_attacking:
            return

        if self.is_blocking:
            return

        if self.is_special:
            return

        if self.is_hit:
            return

        self.is_charging = True

    # ==================================================
    # RELEASE SPECIAL
    # ==================================================

    def release_charge(self, enemy):

        if self.is_dead:
            return

        if not self.is_charging:
            return

        self.is_charging = False

        self.special_attack(enemy)

    # ==================================================
    # SPECIAL ATTACK
    # ==================================================

    def special_attack(self, enemy):

        if self.is_dead:
            return

        if self.is_attacking:
            return

        if self.is_blocking:
            return

        if self.is_special:
            return

        if self.is_hit:
            return

        self.is_special = True
        self.special_frame = 0
        self.special_timer = 0

        self.blast_enemy = enemy
        self.blast_active = False
        self.blast_damage_done = False

        if self.special_sound is not None:

            try:
                self.special_sound.play()
            except pygame.error:
                pass

        if enemy.rect.centerx >= self.rect.centerx:
            self.blast_direction = 1
        else:
            self.blast_direction = -1

    # ==================================================
    # TAKE DAMAGE
    # ==================================================

    def take_damage(self, damage):

        if self.is_dead:
            return

        if self.is_blocking:
            return

        try:
            damage = int(damage)
        except (TypeError, ValueError):
            damage = 0

        if damage < 0:
            damage = 0

        self.health -= damage

        if self.health < 0:
            self.health = 0

        if self.health > 0:

            self.start_hit()

        else:

            self.die()

    # ==================================================
    # HIT
    # ==================================================

    def start_hit(self):

        if self.is_dead:
            return

        if not self.hit_frames:

            self.is_hit = False
            self.image = self.idle_image
            return

        self.is_attacking = False
        self.is_special = False
        self.is_charging = False

        self.is_hit = True
        self.hit_frame = 0
        self.hit_timer = 0

        self.image = self.hit_frames[0]

    # ==================================================
    # DEATH
    # ==================================================

    def die(self):

        self.is_dead = True

        self.is_attacking = False
        self.is_special = False
        self.is_charging = False
        self.is_blocking = False
        self.is_hit = False
        self.blast_active = False

        self.image = self.death_image

    # ==================================================
    # START BLAST
    # ==================================================

    def start_blast(self):

        if self.blast_image is None:
            return

        self.blast_active = True
        self.blast_damage_done = False

        if self.blast_direction == 1:

            self.blast_rect.midleft = (
                self.rect.right - 20,
                self.rect.centery
            )

        else:

            self.blast_rect.midright = (
                self.rect.left + 20,
                self.rect.centery
            )

    # ==================================================
    # UPDATE
    # ==================================================

    def update(self):

        if self.is_dead:
            return

        # -----------------------------
        # HIT ANIMATION
        # -----------------------------

        if self.is_hit:

            self.hit_timer += 1

            if self.hit_timer >= 6:

                self.hit_timer = 0

                if self.hit_frame < len(
                    self.hit_frames
                ):

                    self.image = self.hit_frames[
                        self.hit_frame
                    ]

                    self.hit_frame += 1

                if self.hit_frame >= len(
                    self.hit_frames
                ):

                    self.is_hit = False
                    self.hit_frame = 0
                    self.image = self.idle_image

            return

        # -----------------------------
        # SPECIAL ANIMATION
        # -----------------------------

        if self.is_special:

            self.special_timer += 1

            if self.special_timer >= 5:

                self.special_timer = 0

                if self.special_frames:

                    if self.special_frame < len(
                        self.special_frames
                    ):

                        self.image = self.special_frames[
                            self.special_frame
                        ]

                        self.special_frame += 1

                    if self.special_frame >= len(
                        self.special_frames
                    ):

                        self.is_special = False
                        self.special_frame = 0
                        self.image = self.idle_image

                        self.start_blast()

                else:

                    self.is_special = False
                    self.special_frame = 0
                    self.image = self.idle_image

                    self.start_blast()

        # -----------------------------
        # BLAST
        # -----------------------------

        if self.blast_active:

            self.blast_rect.x += (
                self.blast_speed *
                self.blast_direction
            )

            enemy = self.blast_enemy

            if (
                enemy is not None
                and not self.blast_damage_done
                and not enemy.is_dead
            ):

                if self.blast_rect.colliderect(
                    enemy.rect
                ):

                    if not enemy.is_blocking:
                        enemy.take_damage(20)

                    self.blast_damage_done = True
                    self.blast_active = False

            if (
                self.blast_rect.right < 0
                or self.blast_rect.left > 1280
            ):

                self.blast_active = False

        # -----------------------------
        # BLOCK
        # -----------------------------

        if self.is_blocking:

            self.image = self.block_image
            return

        # -----------------------------
        # PUNCH ANIMATION
        # -----------------------------

        if self.is_attacking:

            self.attack_timer += 1

            if self.attack_timer >= 5:

                self.attack_timer = 0

                if self.punch_frames:

                    if self.attack_frame < len(
                        self.punch_frames
                    ):

                        center = self.rect.center

                        self.image = self.punch_frames[
                            self.attack_frame
                        ]

                        self.rect = self.image.get_rect(
                            center=center
                        )

                        self.attack_frame += 1

                    if self.attack_frame >= len(
                        self.punch_frames
                    ):

                        self.is_attacking = False
                        self.attack_frame = 0
                        self.image = self.idle_image

                else:

                    self.is_attacking = False
                    self.attack_frame = 0
                    self.image = self.idle_image

    # ==================================================
    # DRAW
    # ==================================================

    def draw(self, screen):

        screen.blit(
            self.image,
            self.rect
        )

        if (
            self.blast_active
            and self.blast_image is not None
        ):

            blast = self.blast_image

            if self.blast_direction == -1:

                blast = pygame.transform.flip(
                    blast,
                    True,
                    False
                )

            screen.blit(
                blast,
                self.blast_rect
            )